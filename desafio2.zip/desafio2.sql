/*Create the database if noy exists this database*/
CREATE TABLE IF NOT EXISTS desafioEduardoGodinho123(quantity INT, date DATE, font
VARCHAR);

/*Insert tha data in this table*/
INSERT INTO inscribed(quantity, date, font)
VALUES ( 44, '01/01/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 56, '01/01/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 39, '01/02/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 81, '01/02/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 12, '01/03/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 91, '01/03/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 48, '01/04/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 45, '01/04/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 55, '01/05/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 33, '01/05/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 18, '01/06/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 12, '01/06/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 34, '01/07/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 24, '01/07/2021', 'Página' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 83, '01/08/2021', 'Blog' );
INSERT INTO inscribed(quantity, date, font)
VALUES ( 99, '01/08/2021', 'Página' );

/* 1 -  What register exists  */
SELECT COUNT (*) FROM inscribed;

/*2 - To return something that makes more sense, we actually occupy */
SELECT COUNT (*) AS count_records FROM inscribed;

/*3 - View total subscribers per day */
SELECT SUM(quantity) AS total_enrolled FROM inscribed;

/*4 - Return of old date inscriptions*/
SELECT * FROM inscribed WHERE date = (SELECT MIN(date) FROM inscribed);

/*5 -  SUM the quantity per close after sorting by ascending date */
SELECT date, SUM(quantity) AS total_enrolled FROM inscribed GROUP BY date ORDER BY date ASC;

/*6 - Takes the date and adds the amount, groups by font and sorts by font in ascending order */
SELECT font, SUM(quantity) AS total_enrolled_font FROM inscribed GROUP BY font ORDER BY font ASC;

/*7 - Suma de cantidades por dia y traer el dia que tenga mas inscripciones*/
SELECT date, SUM(quantity) AS quantity_for_day FROM inscribed GROUP BY date ORDER BY quantity_for_day DESC LIMIT 1;

/*9 - selecting maximum amount of blog column */
/* Select date,font,quantity from the inscribed table where quantity is equal to the maximum quantity from the inscribed table where fron is equal to blog*/
SELECT date, font, quantity FROM inscribed WHERE quantity=( SELECT MAX(quantity) FROM inscribed WHERE font='Blog' ) LIMIT 1;

/*10 - See the average number of registrations in a day */
SELECT AVG(result.registered_per_day) FROM (SELECT date, SUM(quantity) AS registered_per_day FROM inscribed GROUP BY date ORDER BY date) AS result;

/* Returns the days where the number of entries is greater than 50 */
/* HAVING is executed first and calculates which data is greater than 50 then selects the date and sums up the quantity */
SELECT date, SUM(quantity) AS total_enrolled FROM inscribed GROUP BY date HAVING(SUM(quantity) > 50) ORDER BY date ASC;

/* Take the average per day from the 3rd day */
SELECT AVG(result.registered_per_day) FROM (SELECT date, SUM(quantity) AS registered_per_day FROM inscribed WHERE date >= '01/03/2021' GROUP BY date) AS result;
